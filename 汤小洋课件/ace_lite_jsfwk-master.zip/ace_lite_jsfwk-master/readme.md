详见：https://gitee.com/openharmony/docs/blob/master/readme/JS应用开发框架README.md

see: https://gitee.com/openharmony/docs/blob/master/docs-en/readme/js-application-framework.md